from django.apps import AppConfig


class ToywikiConfig(AppConfig):
    name = 'toywiki'
